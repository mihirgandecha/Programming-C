Find attached launch.json and try running
- Wanted to enhance debugging skills.
- Learned about JSON files.
- Attached `launch.json` takes one or two arguments.
- Learning not to use `task.json` was challenging.
- Wanted to run Makefile commands manually.
- Debugging configurations created for different parts of the project.
- Used GDB for debugging with pretty-printing enabled.
- Each configuration tailored for specific files and tasks.
- Debugging helped in understanding and fixing issues.
