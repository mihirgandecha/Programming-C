#include <stdio.h>
#include <stdlib.h>

void on_error(const char* s);
void* ncalloc(int n, size_t size);
