x=[]
print(x)
x.append(5)
x.append("Sahil")
print(x)