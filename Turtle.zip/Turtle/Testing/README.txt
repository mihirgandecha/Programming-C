Nothing here yet

Parsing Test:
White-box Testing:
-Testing Input/Output 
-Therefore running through TTLs provided
-Wrote new to include more edge cases
	-perhaps more ttl that will parse but doesnt interpret?

Black-box Testing:
-Testing I/O, but also internal testing
-Bash script to check error messaging
-assert testing each function for recursive nature
